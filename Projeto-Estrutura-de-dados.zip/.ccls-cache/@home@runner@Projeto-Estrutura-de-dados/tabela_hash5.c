#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <stdbool.h>

#define TAM 53

typedef struct nodo {
    struct nodo *proximo;
    struct nodo *anterior;
    char nome[50];
} Nodo;

typedef struct sLista {
    struct nodo *inicio;
    struct nodo *final;
    int tam;
} Lista;

void menuDeOpcoes();
void inicializarLista(Lista *lista);
void inicializarTabela(Lista t[]);
void inserirNomeLista(Lista *lista, char nome[]);
int inserirEmListaComRetorno(Lista *lista, char nome[]);
void inserirComRetorno(Lista t[], char nome[]);
void adicionar(Lista t[], char nome[]);
void criacaotabela(Lista t[]);
void percorreLetras(Lista t[]);
int funcaoHash(char nome[]);
char* buscalista(Lista *lista, char nome[]);
void busca(Lista t[], char nome[]);
bool remover(Lista *lista, char nome[]);
void removerNomelista(Lista t[], char nome[]);
void imprimirlistagem(Lista *lista);
void mostrarTabelas(Lista t[]);
void MostraListaOrdenada(Lista *lista);
void fazerTroca(Nodo *a, Nodo *b);
void CmdLimpo();
int apenasNum(char opcao[]);
void histograma(Lista t[]);
Nodo *particao(Nodo *primeiro, Nodo *ultimo);
void quicksort(Nodo *primeiro, Nodo *ultimo);

void inicializarLista(Lista *lista) {
    lista->inicio = NULL;
    lista->final = NULL;
    lista->tam = 0;
}

void inserirNomeLista(Lista *lista, char nome[]) {
    Nodo *nodo = malloc(sizeof(Nodo));

    if (nodo) {
        strcpy(nodo->nome, nome);
        nodo->proximo = NULL;
        nodo->anterior = NULL;

        if (lista->inicio == NULL) {
            lista->inicio = nodo;
            lista->final = nodo;
        } else {
            nodo->proximo = lista->inicio;
            lista->inicio->anterior = nodo;
            lista->inicio = nodo;
        }
        lista->tam++;
      
    } else {
        printf("\n\t Erro no alocar a memória!\n");
      
    }
}

bool remover(Lista *lista, char nome[]) {
    Nodo *aux = lista->inicio;

    if (aux != NULL && strcmp(aux->nome, nome) == 0) {
        lista->inicio = aux->proximo;
        if (lista->inicio != NULL)
            lista->inicio->anterior = NULL;
        free(aux);
        lista->tam--;
        return true;
    }

    while (aux != NULL && strcmp(aux->nome, nome) != 0)
        aux = aux->proximo;

    if (aux != NULL) {
        if (aux->anterior != NULL)
            aux->anterior->proximo = aux->proximo;
        if (aux->proximo != NULL)
            aux->proximo->anterior = aux->anterior;
        if (aux == lista->final)
            lista->final = aux->anterior;
        free(aux);
        lista->tam--;
        return true;
    }
    return false;
    }
    
    void removerNomelista(Lista t[], char nome[]) {
    int id = funcaoHash(nome);
    if(remover(&t[id], nome)){
    	printf("%s foi removido\n", nome);
	}else{
		printf("%s Deu erro pra remover\n", nome);
	}
    
}


int inserirEmListaComRetorno(Lista *lista, char nome[]) {
    Nodo *nodo = malloc(sizeof(Nodo));

    if (nodo) {
        for (int i = 0; i < strlen(nome); i++) {
            nodo->nome[i] = toupper(nome[i]);
        }

        nodo->proximo = NULL;
        nodo->anterior = NULL;

        if (lista->inicio == NULL) {
            lista->inicio = nodo;
            lista->final = nodo;
        } else {
            nodo->proximo = lista->inicio;
            lista->inicio->anterior = nodo;
            lista->inicio = nodo;
        }
        lista->tam++;
        return 1;
    } else {
        printf("\n\tErro ao alocar memória!\n");
        return 0;
    }
}

void inserirComRetorno(Lista t[], char nome[]) {
    int id = funcaoHash(nome);
    inserirNomeLista(&t[id], nome);
    printf("%s agora está nessa lista %d", nome, id);
}


void imprimirlistagem(Lista *lista) {
    Nodo *aux = lista->inicio;
    int cont=0;
    printf("\n\n Tam %d: ", lista->tam);
    while (aux && cont <=50 ) {
        printf("%s,", aux->nome);
        aux = aux->proximo;
        cont++;
    }
}

void inicializarTabela(Lista t[]) {
    int i;

    for (i = 0; i < TAM; i++) {
        inicializarLista(&t[i]);
    }
}

int funcaoHash(char nome[]) {
    int h = 0;
    for (int i = 0; i < strlen(nome); i++) {
            nome[i] = toupper(nome[i]);
        }
    for (int i = 0; i < strlen(nome); i++)
        h = (31 * h + nome[i]) % TAM;
    return h;
}

char* buscalista(Lista *lista, char nome[]) {
    Nodo *aux = lista->inicio;
    for (int i = 0; i < strlen(nome); i++) {
            nome[i] = toupper(nome[i]);
        }
    nome[strlen(nome)] = '\0';    
    while (aux && strcmp(aux->nome, nome) != 0)
        aux = aux->proximo;
    if (aux)
        return aux->nome;
        
    return NULL;
}

void busca(Lista t[], char nome[]) {
    int id = funcaoHash(nome);
    if(buscalista(&t[id], nome) != NULL){
        printf("%s foi encontrado na lista %d", nome,id);
    }else{
    	printf("%s não encontrou", nome);
	};
}

void adicionar(Lista t[], char nome[]) {
    int id = funcaoHash(nome);
    inserirNomeLista(&t[id], nome);
}

void mostrarTabelas(Lista t[]) {
    int i;
    for (i = 0; i < TAM; i++) {
        printf("%d = ", i);
        imprimirlistagem(&t[i]);
        printf("\n");
    }
}

void fazerTroca(Nodo *a, Nodo *b) {
    char temp[50];
    strcpy(temp, a->nome);
    strcpy(a->nome, b->nome);
    strcpy(b->nome, temp);
}

Nodo *particao(Nodo *primeiro, Nodo *ultimo) {
    char* pivot = primeiro->nome;
    Nodo *i = primeiro->proximo;
    Nodo *j = ultimo;

    while (i != j->proximo) {
        while (i != j->proximo && strcmp(i->nome, pivot) <= 0)
            i = i->proximo;
        while (j != primeiro && strcmp(j->nome, pivot) > 0)
            j = j->anterior;

        if (i != j->proximo)
            fazerTroca(i, j);
    }

    fazerTroca(primeiro, j);

    return j;
}

void quicksort(Nodo *primeiro, Nodo *ultimo) {
    if (primeiro != NULL && ultimo != NULL && primeiro != ultimo && primeiro != ultimo->proximo) {
        Nodo *pivot = particao(primeiro, ultimo);
        quicksort(primeiro, pivot->anterior);
        quicksort(pivot->proximo, ultimo);
    }
}

void MostraListaOrdenada(Lista *lista) {
    quicksort(lista->inicio, lista->final);
}

void CmdLimpo() {
    #if defined(_WIN32) || defined(_WIN64)
        system("cls");
    #else
        system("clear");
    #endif
}

int apenasNum(char opcao[]) {
    for (int i = 0; opcao[i] != '\0'; i++) {
        if (isdigit(opcao[i])) {
            printf(" Apenas numeros \n");
            return 0;
        }
    }
    return 1;
}

void histograma(Lista t[]) {
    int i, j;
    int maxCount = 0;
    int setNum = 10;

    for (i = 0; i < TAM; i++) {
        if (t[i].tam > maxCount) {
            maxCount = t[i].tam;
        }
    }

    for (i = maxCount; i > 0; i -= 10) {
        printf("%2d   ", i);
        for (j = 0; j < setNum; j++) {
            if (t[j].tam >= i) {
                printf(".");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    
    printf("     ");
    printf("\n");
    printf("     ");
  
    for (i = 0; i < setNum; i++) {
        printf("%2d ", i);
    }
    printf("\n");
}

void criacaoTabela(Lista t[]) {
    FILE *arquivo;
    arquivo = fopen("tabela.csv", "w");

    for (int i = 0; i < TAM; i++) {
        fprintf(arquivo, "%d\n", t[i].tam);
    }

    fclose(arquivo);

    printf("Pronto\n");
}

void percorreLetras(Lista t[]) {
    int contagem[26] = {0};
    for (int i = 0; i < TAM; i++) {
        Nodo *aux = t[i].inicio;
        while (aux != NULL) {
        	char primeiraLetra = aux->nome[0];
            if (primeiraLetra >= 'A' && primeiraLetra <= 'Z') {
                contagem[primeiraLetra - 'A']++;
            }
            aux = aux->proximo;
        }
    }

    for (int i = 0; i < 26; i++) {
        printf("%c: %d\n", 'A' + i, contagem[i]);
    }
}

void menuDeOpcoes() {
    printf("1 | Para inserir algum nome\n\n");
    printf("2 | Para remover algum nome\n\n");
    printf("3 | Para buscar algum nome\n\n");
    printf("4 | Para imprimir cada lista\n\n");
    printf("5 | Para ordenar listas\n\n");
    printf("6 | Para ver o histograma\n\n");
    printf("7 | Para exportar tabela excel\n\n");
    printf("8 | Para exibir tabela por índice\n\n");
    printf("9 | Para caso deseje fechar tudo\n\n");
}

int main() {

    Lista tabela[TAM];
    inicializarTabela(tabela);

    FILE *arquivo;
    char linha[50];
    int verifica=0;
    arquivo = fopen("nomes.txt", "r");

    if (arquivo == NULL) {
        printf("não tem arquivo\n");
        return 0;
    }

    while (fgets(linha, sizeof(linha), arquivo) != NULL) {
        linha[strcspn(linha, "\n")] = '\0';
        adicionar(tabela, linha);
    }

    fclose(arquivo);
    

    int escolha=0;
    char nome[50];

    do {
        CmdLimpo();
        menuDeOpcoes();
   
       
        
		scanf("%d", &escolha);
	

        switch (escolha) {
            case 1://*************************************************************
                CmdLimpo();
                verifica = 0;
                while(verifica == 0){
                    printf(" Qual nome você quer inserir? ");
                    scanf("%s", nome);
                    verifica = apenasNum(nome);
                }
                inserirComRetorno(tabela, nome);
            break;

            case 2://**********************************************************
    			    CmdLimpo();
    			    verifica = 0;
    			    while (verifica == 0) {
    			        printf(" Qual nome você quer remover? ");
    			        scanf("%s", nome);
    			        verifica = apenasNum(nome);
    			    }
    			    removerNomelista(tabela, nome);
			      break;

            case 3://**********************************************************
                CmdLimpo();
                verifica = 0;
                while(verifica == 0){
                    printf(" Qual nome você quer buscar? ");
                    scanf("%s", nome);
                    verifica = apenasNum(nome);
                }
            	busca(tabela,nome);
            break;   

            case 4://**********************************************************
                CmdLimpo();
                mostrarTabelas(tabela);
            break;

            case 5://**********************************************************
                CmdLimpo();
                for (int i = 0; i < TAM; i++) {
                    MostraListaOrdenada(&tabela[i]);
                }
                printf("Pronto\n");
            break;

            case 6://**********************************************************
                CmdLimpo();
				        histograma(tabela);             
            break;

            case 7: {//*********************************************************
                criacaoTabela(tabela);
                break;
            }

			      case 8://**********************************************************
			         CmdLimpo();
			         percorreLetras(tabela);
			      break;    

            case 9://**********************************************************
                CmdLimpo();
                printf("Fechando tudo\n");
            break;

        }

        printf("\n\n Se quiser voltar ao menu, aperte a tecla Enter ");
        getchar();
        getchar();
    } while (escolha != 9);
    return 0;
}